import pandas as pd

# Load the Billboard 100 data
billboard_df = pd.read_csv(r'C:\Users\Sdean\OneDrive\Documents\SpringBoard\Capstone 1\Billboard100rank2023up.csv')

# Load the songs genres data
songs_genres_df = pd.read_csv(r'C:\Users\Sdean\OneDrive\Documents\SpringBoard\Capstone 1\songs_genres_modified.csv')

# Merge the two DataFrames on artist and song columns
merged_df = pd.merge(billboard_df, songs_genres_df, how='left', on=['Artist', 'Song'])

# Write the merged DataFrame to a new CSV file
output_file_path = r'C:\Users\Sdean\OneDrive\Documents\SpringBoard\Capstone 1\billboard1002023final.csv'
merged_df.to_csv(output_file_path, index=False)

print(f'Merged DataFrame has been written to: {output_file_path}')
