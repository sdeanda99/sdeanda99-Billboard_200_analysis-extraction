# Import required libraries
import pandas as pd
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import time
from pathlib import Path
import traceback
from tqdm import tqdm
import json
import os

# Spotify API credentials
client_id = ''
client_secret = ''

# Set up Spotify client
client_credentials_manager = SpotifyClientCredentials(client_id=client_id, client_secret=client_secret)
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)

def get_genres(song_name, artist_name):
    """
    Fetch genres for a given song and artist from Spotify API
    """
    try:
        # Search for the track
        result = sp.search(q=f"{song_name} {artist_name}", type='track', limit=1)
        if not result['tracks']['items']:
            print(f"No results for {song_name} by {artist_name}")
            return ""
        
        # Get artist details
        track = result['tracks']['items'][0]
        artist_id = track['artists'][0]['id']
        artist = sp.artist(artist_id)
        artist_genres = artist['genres']
        
        return ", ".join(artist_genres)
    except spotipy.client.SpotifyException as e:
        if e.http_status == 429:  # Check if rate limited
            print("Rate limited. Waiting for cooldown...")
            time.sleep(10)  # Wait for cooldown, adjust as needed
            return get_genres(song_name, artist_name)  # Retry the request
        else:
            print(f"Error fetching genres for {song_name} by {artist_name}: {e}")
            return ""
    except Exception as e:
        trace = traceback.format_exc()
        print(f"Error fetching genres for {song_name} by {artist_name}: {e} \n {trace}")
        return ""

# Path to the Billboard CSV file
billboard_dir = Path('./Billboard100rank2023up.csv')

# Read the CSV file
df = pd.read_csv(billboard_dir)

# Add 'Genre' column if it doesn't exist
if 'Genre' not in df.columns:
    df['Genre'] = ""
df['Genre'] = df['Genre'].astype(str)

size_df = df.shape[0]

# Load or create cache dictionary
if not os.path.exists("./cachedict.json"):
    cachedict = {}
    with open("cachedict.json", "w") as f:
        json.dump(cachedict, f)
else:
    with open("./cachedict.json", "r") as f:
        cachedict = json.load(f)

# Iterate through each row in the DataFrame
for index, row in tqdm(df.iterrows(), total=size_df, desc='Processing'):
    print(f"Processing {index + 1}/{len(df)}: {row['Song']} by {row['Artist']}")
    
    # Skip if already in cache
    if f"{row['Song']}_{row['Artist']}" in cachedict:
        continue
    
    # Get genres for the current song
    genres = get_genres(row['Song'], row['Artist'])
    
    # Update cache
    cachedict[f"{row['Song']}_{row['Artist']}"] = genres
    with open("cachedict.json", "w") as f:
        json.dump(cachedict, f)
    
    time.sleep(1)  # Adding a delay to avoid hitting API rate limits

# Update the DataFrame with genres from cache
df['Genre'] = list(cachedict.values())

# Save the updated DataFrame
df.to_csv(billboard_dir, index=False)
print("Update complete.")