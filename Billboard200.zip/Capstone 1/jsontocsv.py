import pandas as pd

# Load the songs genres data
songs_genres_df = pd.read_csv(r'C:\Users\Sdean\OneDrive\Documents\SpringBoard\Capstone 1\songs_genres.csv')

# Split the 'Song' column into 'Song' and 'Artist' columns
songs_genres_df[['Song', 'Artist']] = songs_genres_df['Song'].str.split(' by ', expand=True)

# Optionally, save the modified DataFrame back to a CSV file if needed
modified_file_path = r'C:\Users\Sdean\OneDrive\Documents\SpringBoard\Capstone 1\songs_genres_modified.csv'
songs_genres_df.to_csv(modified_file_path, index=False)

print(f'Modified DataFrame has been written to: {modified_file_path}')
